﻿//-----------------------------------------------------------------------
// <copyright file="AssemblyInfo.cs" company="OxyPlot">
//     http://oxyplot.codeplex.com, license: MIT
// </copyright>
//-----------------------------------------------------------------------

using System.Reflection;

[assembly: AssemblyTitle("OxyPlot for Windows Forms")]
[assembly: AssemblyDescription("OxyPlot controls for Windows Forms.")]